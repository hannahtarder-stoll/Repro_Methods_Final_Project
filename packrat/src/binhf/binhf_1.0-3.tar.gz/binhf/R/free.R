"free" <-
function(x,n){
c<-n+1
a<-asin((x/c)^.5)+asin(((x+1)/c)^.5)
a
}

