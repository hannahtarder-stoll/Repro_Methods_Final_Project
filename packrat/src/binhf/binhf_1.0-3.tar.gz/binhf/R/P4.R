"P4" <-
function(t){
y<-(P2(t)/4)+.75
y<-4*y
}

