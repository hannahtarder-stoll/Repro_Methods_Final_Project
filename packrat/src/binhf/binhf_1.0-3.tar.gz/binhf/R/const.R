`const` <-
function(t,val=.5){y<-rep(val,times=length(t))}

