`Bumps` <-
function(x){make.signal2("bumps",x=x)/5.25}

