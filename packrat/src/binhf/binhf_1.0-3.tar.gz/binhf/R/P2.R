"P2" <-
function(t){
y<--(t^2)/(1-t^2)
y<-exp(y)
y<-y*(t+.01)^.25
}

